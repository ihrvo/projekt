<?php

use App\Http\Controllers\AnimalController;
use App\Http\Controllers\CarController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


Route::middleware(['auth.admin'])->group(
    function () {
        Route::get('/animal/{name}', [AnimalController::class, 'getAnimal']);
        Route::post('/animal', [AnimalController::class, 'store']);
        Route::resource('/cars', CarController::class);
        Route::get('/admin/dashboard', function () {
            return 'Dobrodošli na admin dashboard!';
        });
    }
);